# BIN Y VUELTAS RD — Guía para publicarla en Railway

## Lo que vas a lograr
Tu app pública en internet, donde todas las personas crean su cuenta con
@usuario + clave única, los mensajes se guardan en el servidor y llegan en
vivo a todos los dispositivos.

## Paso 1 — Sube el código a GitHub (5 minutos)
1. Entra a **github.com** y crea una cuenta (o entra a la tuya).
2. Crea un repositorio nuevo llamado `bin-y-vueltas-rd` (botón New, público o privado).
3. En tu computadora, abre la carpeta de este proyecto y sube todos los
   archivos al repositorio (puedes arrastrarlos en la página de GitHub:
   "uploading an existing file").

Archivos que debe tener el repositorio:
- `server.js`, `package.json`, `railway.json`, `.env.example`, `.gitignore`
- carpeta `public/` con `index.html`, `styles.css`, `app.js`

## Paso 2 — Conéctalo a Railway (3 minutos)
1. Entra a **railway.app** con tu cuenta.
2. Botón **New Project** → **Deploy from GitHub repo** → elige `bin-y-vueltas-rd`.
3. Railway instala y enciende solo. Espera a que diga **Active**.
4. En la pestaña **Settings** del servicio, busca **Networking** →
   **Generate Domain**. Te dará un link como
   `bin-y-vueltas-rd-production.up.railway.app`. ¡Ese ya es tu link público!

## Paso 3 — Que no se borren los datos (2 minutos, recomendado)
1. En Railway, pestaña **Volumes** → **New Volume**, punto de montaje: `/data`.
2. En **Variables**, agrega: `DB_PATH` = `/data/data.sqlite`.
3. Redeploy (pestaña Deployments → ⋯ → Redeploy).

Sin esto, cada vez que Railway reinicie, las cuentas se borran.

## Paso 4 — Tu dominio propio (opcional)
1. Compra el dominio en Namecheap o Cloudflare (ej: `binyvueltasrd.com`).
2. En Railway → Settings → Networking → **Custom Domain**, escribe tu dominio.
3. En tu proveedor del dominio, agrega el registro CNAME que Railway te indique.
4. Espera unos minutos y tu app abrirá en tu `.com`.

## Probar
1. Abre el link en tu teléfono, regístrate (te da tu clave única BV-…).
2. Abre el mismo link en otro dispositivo o navegador, crea otra cuenta.
3. Búscate por @usuario en Contactos, abre el chat y escríbanse: los mensajes
   llegan en vivo. Prueba fotos, notas de voz, historias y llamadas.

## Costos aproximados
- Railway: ~$5/mes (plan Hobby).
- Dominio: ~$10–15/año.

## Seguridad y lanzamiento (ya aplicado y verificado)
- **Claves** con bcrypt (costo 12); sesiones con expiración de 7 días y limpieza automática.
- **Rate limiting:** 20 intentos/15 min en login/registro; 600 req/15 min en la API.
- **Cabeceras:** CSP, HSTS (1 año), X-Frame-Options DENY, nosniff, Referrer-Policy.
- **HTTPS:** redirección 301 automática de HTTP→HTTPS (Railway da el certificado SSL).
- **Anti-IDOR:** cada endpoint valida que el usuario sea miembro del chat/recurso.
- **Anti-XSS:** consultas parametrizadas + escape en el frontend + sanitización.
- **Anti-CSRF:** autenticación por Bearer (sin cookies) + verificación de origen.
- **Anti-spam:** honeypot invisible en registro/login + rate limiting.
- **Uploads:** solo tipos permitidos, 100 MB máx, imágenes JPG/PNG → WebP automático.
- **SEO:** title/description, Open Graph + Twitter Cards, sitemap.xml, robots.txt.
- **Legal:** `/privacidad.html` y `/terminos.html` + banner de consentimiento.
- **Rendimiento:** gzip, cacheo de assets, lazy loading en imágenes.
- **Accesibilidad:** contraste WCAG AA, `alt` en imágenes, diseño responsive.
- **Secretos:** todo por variables de entorno (`.env`); nada sensible en el código.
- **Analytics:** GA4 listo — pega tu ID en `window.GA4_ID` dentro de `public/index.html`.
