// BIN Y VUELTAS RD - Servidor de mensajería en tiempo real
// Endurecido para producción: bcrypt, sesiones con expiración, rate limiting,
// cabeceras de seguridad, HTTPS/HSTS, sanitización y control de acceso.
const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const compression = require('compression');
let sharp = null;
try { sharp = require('sharp'); } catch (e) { /* optimización de imágenes opcional */ }
const { v4: uuidv4 } = require('uuid');
const sqlite3 = require('sqlite3').verbose();
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: false }, maxHttpBufferSize: 50 * 1024 * 1024 });

// Detrás de Railway/proxy: IP real del cliente para rate limiting
app.set('trust proxy', 1);

// ---------- Compresión gzip/brotli (velocidad de carga) ----------
app.use(compression());

// ---------- 4. Forzar HTTPS: redirigir HTTP → HTTPS ----------
// Railway y la mayoría de hostings terminan TLS y mandan x-forwarded-proto.
app.use((req, res, next) => {
  const proto = req.headers['x-forwarded-proto'];
  if (proto && proto !== 'https' && process.env.FORCE_HTTPS !== 'off') {
    return res.redirect(301, 'https://' + req.headers.host + req.originalUrl);
  }
  next();
});

const PORT = process.env.PORT || 3000;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data.sqlite');
const UPLOAD_DIR = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ---------- 4. Cabeceras de seguridad ----------
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"], // la SPA usa manejadores inline
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "blob:"],
      mediaSrc: ["'self'", "blob:", "data:"],
      connectSrc: ["'self'", "ws:", "wss:"],
      fontSrc: ["'self'", "data:"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"]
    }
  },
  hsts: { maxAge: 31536000, includeSubDomains: true, preload: true }, // HTTPS obligatorio
  frameguard: { action: 'deny' },          // X-Frame-Options: DENY (anti clickjacking)
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' }
}));
// X-Content-Type-Options: nosniff lo pone helmet por defecto.

// ---------- 6. Rate limiting ----------
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false,
  message: { error: 'too_many_attempts' }
});
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, max: 600, standardHeaders: true, legacyHeaders: false,
  message: { error: 'too_many_requests' }
});
app.use('/api/', apiLimiter);
app.use('/api/login', authLimiter);
app.use('/api/register', authLimiter);

app.use(express.json({ limit: '1mb' })); // JSON pequeño; archivos van por /api/upload
// Cacheo de assets estáticos (velocidad): 1 día para la SPA, 1 año para uploads con nombre único
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: '1d',
  setHeaders: (res, p) => { if (p.endsWith('index.html')) res.setHeader('Cache-Control', 'no-cache'); }
}));
app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '1y', immutable: true }));

// ---------- 3b. Sanitización anti-XSS ----------
function sanitizeText(s, max) {
  let out = String(s || '');
  out = out.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, ''); // sin caracteres de control
  out = out.trim().slice(0, max);
  return out;
}

const db = new sqlite3.Database(DB_PATH);
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, name TEXT, username TEXT UNIQUE, key_hash TEXT,
    bio TEXT DEFAULT '', photo TEXT DEFAULT '', created_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id TEXT, created_at INTEGER, expires_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY, type TEXT, title TEXT, username TEXT UNIQUE, photo TEXT DEFAULT '', created_by TEXT, created_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS members (conv_id TEXT, user_id TEXT, role TEXT DEFAULT 'member', PRIMARY KEY (conv_id, user_id))`);
  db.run(`CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY, conv_id TEXT, sender_id TEXT, kind TEXT, text TEXT,
    media_url TEXT, duration_sec INTEGER DEFAULT 0, created_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS stories (
    id TEXT PRIMARY KEY, user_id TEXT, media_url TEXT, caption TEXT, created_at INTEGER, expires_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS calls (
    id TEXT PRIMARY KEY, caller_id TEXT, callee_id TEXT, kind TEXT, status TEXT, started_at INTEGER, ended_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS bots (
    id TEXT PRIMARY KEY, owner_id TEXT, name TEXT, username TEXT UNIQUE, token TEXT UNIQUE, created_at INTEGER)`);
  // Migración: columna de expiración si la tabla ya existía
  db.run(`ALTER TABLE sessions ADD COLUMN expires_at INTEGER`, () => {});
});

const q = (sql, p = []) => new Promise((res, rej) => db.all(sql, p, (e, r) => e ? rej(e) : res(r)));
const run = (sql, p = []) => new Promise((res, rej) => db.run(sql, p, function (e) { e ? rej(e) : res(this); }));
const one = (sql, p = []) => q(sql, p).then(r => r[0]);

// ---------- 1. Sesiones con expiración corta (7 días, deslizante) ----------
const SESSION_TTL_MS = 7 * 24 * 3600 * 1000;
async function createSession(userId) {
  const token = uuidv4();
  const now = Date.now();
  await run('INSERT INTO sessions (token,user_id,created_at,expires_at) VALUES (?,?,?,?)',
    [token, userId, now, now + SESSION_TTL_MS]);
  return token;
}
// Limpieza periódica de sesiones expiradas
setInterval(() => { db.run('DELETE FROM sessions WHERE expires_at < ?', [Date.now()], () => {}); }, 3600 * 1000);

function genKey() {
  const s = () => Math.random().toString(36).slice(2, 6).toUpperCase().padStart(4, '0');
  return `BV-${s()}-${s()}-${s()}`;
}
function genBotToken() { return 'BV' + uuidv4().replace(/-/g, '').slice(0, 30); }
function cleanUsername(u) { return String(u || '').trim().replace(/^@/, '').toLowerCase().replace(/[^a-z0-9_.]/g, '').slice(0, 30); }

// ---------- 3c. Anti-CSRF: solo mismo origen (la SPA vive en el mismo host) ----------
// La API usa Authorization: Bearer (sin cookies), así que no hay credenciales
// ambientales que un sitio atacante pueda reutilizar. Refuerzo extra:
function sameOrigin(req, res, next) {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    const origin = req.headers.origin;
    if (origin) {
      const host = req.headers.host;
      try {
        if (new URL(origin).host !== host) return res.status(403).json({ error: 'csrf_blocked' });
      } catch { return res.status(403).json({ error: 'csrf_blocked' }); }
    }
  }
  next();
}
app.use('/api/', sameOrigin);

async function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!token || token.length > 100) return res.status(401).json({ error: 'no_auth' });
  const s = await one('SELECT * FROM sessions WHERE token=?', [token]);
  if (!s || s.expires_at < Date.now()) {
    if (s) await run('DELETE FROM sessions WHERE token=?', [token]);
    return res.status(401).json({ error: 'session_expired' });
  }
  // Expiración deslizante: renueva mientras se usa
  await run('UPDATE sessions SET expires_at=? WHERE token=?', [Date.now() + SESSION_TTL_MS, token]);
  req.user = await one('SELECT id,name,username,bio,photo,created_at FROM users WHERE id=?', [s.user_id]);
  if (!req.user) return res.status(401).json({ error: 'no_user' });
  next();
}

// ---------- 2. Control de acceso: el usuario solo toca sus recursos ----------
async function requireMember(req, res, next) {
  const mb = await one('SELECT * FROM members WHERE conv_id=? AND user_id=?', [req.params.id, req.user.id]);
  if (!mb) return res.status(403).json({ error: 'forbidden' }); // anti-IDOR
  next();
}

// ---------- Auth ----------
app.post('/api/register', async (req, res) => {
  try {
    // 18. Honeypot anti-spam: los bots rellenan el campo oculto "website"
    if (req.body.website) { await new Promise(r => setTimeout(r, 500)); return res.status(200).json({ ok: true }); }
    const name = sanitizeText(req.body.name, 60);
    const username = cleanUsername(req.body.username);
    if (!name || username.length < 3) return res.status(400).json({ error: 'invalid' });
    if (await one('SELECT id FROM users WHERE username=?', [username])) return res.status(409).json({ error: 'taken' });
    const key = genKey();
    const id = uuidv4();
    // 1. bcrypt con costo 12 para la clave única
    await run('INSERT INTO users (id,name,username,key_hash,created_at) VALUES (?,?,?,?,?)',
      [id, name, username, bcrypt.hashSync(key, 12), Date.now()]);
    const savedId = uuidv4();
    await run('INSERT INTO conversations (id,type,title,created_by,created_at) VALUES (?,?,?,?,?)', [savedId, 'saved', 'Mensajes guardados', id, Date.now()]);
    await run('INSERT INTO members (conv_id,user_id,role) VALUES (?,?,?)', [savedId, id, 'owner']);
    const token = await createSession(id);
    res.json({ token, key, user: { id, name, username } });
  } catch (e) { res.status(500).json({ error: 'server' }); }
});

app.post('/api/login', async (req, res) => {
  try {
    if (req.body.website) { await new Promise(r => setTimeout(r, 500)); return res.status(401).json({ error: 'bad_credentials' }); }
    const username = cleanUsername(req.body.username);
    const key = sanitizeText(req.body.key, 40).toUpperCase();
    const u = await one('SELECT * FROM users WHERE username=?', [username]);
    // Comparación en tiempo constante-ish vía bcrypt; no revelar si el usuario existe
    const ok = u && bcrypt.compareSync(key, u.key_hash);
    if (!ok) { await new Promise(r => setTimeout(r, 300)); return res.status(401).json({ error: 'bad_credentials' }); }
    const token = await createSession(u.id);
    res.json({ token, user: { id: u.id, name: u.name, username: u.username, bio: u.bio, photo: u.photo } });
  } catch (e) { res.status(500).json({ error: 'server' }); }
});

app.post('/api/logout', auth, async (req, res) => {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  await run('DELETE FROM sessions WHERE token=?', [token]);
  res.json({ ok: true });
});

app.get('/api/me', auth, (req, res) => res.json({ user: req.user }));

app.post('/api/profile', auth, async (req, res) => {
  const name = sanitizeText(req.body.name, 60) || req.user.name;
  const bio = sanitizeText(req.body.bio, 200);
  let photo = sanitizeText(req.body.photo, 300);
  // La foto debe ser un archivo subido al propio servidor (anti-XSS por URL externa)
  if (photo && !photo.startsWith('/uploads/')) photo = '';
  await run('UPDATE users SET name=?, bio=?, photo=? WHERE id=?', [name, bio, photo, req.user.id]);
  res.json({ ok: true });
});

app.post('/api/regen-key', auth, async (req, res) => {
  const key = genKey();
  await run('UPDATE users SET key_hash=? WHERE id=?', [bcrypt.hashSync(key, 12), req.user.id]);
  await run('DELETE FROM sessions WHERE user_id=?', [req.user.id]); // invalida otras sesiones
  const token = await createSession(req.user.id);
  res.json({ key, token });
});

// ---------- Uploads con validación de tipo ----------
const ALLOWED_MIME = new Set([
  'image/jpeg', 'image/png', 'image/gif', 'image/webp',
  'video/mp4', 'video/webm', 'video/quicktime',
  'audio/webm', 'audio/mpeg', 'audio/mp4', 'audio/ogg',
  'application/pdf', 'text/plain'
]);
const storage = multer.diskStorage({
  destination: UPLOAD_DIR,
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase().slice(0, 10);
    cb(null, Date.now() + '-' + Math.round(Math.random() * 1e9) + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (ALLOWED_MIME.has(file.mimetype)) cb(null, true);
    else cb(new Error('filetype_not_allowed'));
  }
});
app.post('/api/upload', auth, (req, res) => {
  upload.single('file')(req, res, async (err) => {
    if (err || !req.file) return res.status(400).json({ error: 'bad_file' });
    let filename = req.file.filename;
    // 11. Comprimir imágenes a WebP (menos peso, mismo aspecto)
    if (sharp && /^image\/(jpeg|png)$/.test(req.file.mimetype)) {
      try {
        const webpName = filename.replace(/\.[^.]+$/, '') + '.webp';
        await sharp(req.file.path).rotate().resize({ width: 1600, withoutEnlargement: true }).webp({ quality: 80 }).toFile(path.join(UPLOAD_DIR, webpName));
        fs.unlink(req.file.path, () => {});
        filename = webpName;
      } catch (e) { /* si falla, se sirve el original */ }
    }
    res.json({ url: '/uploads/' + filename });
  });
});

// ---------- Chats ----------
app.get('/api/chats', auth, async (req, res) => {
  const rows = await q(`SELECT c.id,c.type,c.title,c.username,c.photo,c.created_at,
    (SELECT text FROM messages m WHERE m.conv_id=c.id ORDER BY created_at DESC LIMIT 1) AS last_text,
    (SELECT kind FROM messages m WHERE m.conv_id=c.id ORDER BY created_at DESC LIMIT 1) AS last_kind,
    (SELECT created_at FROM messages m WHERE m.conv_id=c.id ORDER BY created_at DESC LIMIT 1) AS last_at
    FROM conversations c JOIN members mb ON mb.conv_id=c.id WHERE mb.user_id=? ORDER BY COALESCE(last_at, c.created_at) DESC`, [req.user.id]);
  res.json({ chats: rows });
});

app.post('/api/chats/direct', auth, async (req, res) => {
  const other = cleanUsername(req.body.username);
  const u = await one('SELECT id FROM users WHERE username=?', [other]);
  if (!u) return res.status(404).json({ error: 'not_found' });
  if (u.id === req.user.id) return res.status(400).json({ error: 'self' });
  const mine = await q('SELECT conv_id FROM members WHERE user_id=?', [req.user.id]);
  for (const m of mine) {
    const c = await one('SELECT id FROM conversations WHERE id=? AND type=?', [m.conv_id, 'direct']);
    if (!c) continue;
    const om = await one('SELECT user_id FROM members WHERE conv_id=? AND user_id=?', [c.id, u.id]);
    if (om) return res.json({ chat: await one('SELECT id,type,title,username FROM conversations WHERE id=?', [c.id]) });
  }
  const id = uuidv4();
  await run('INSERT INTO conversations (id,type,title,created_by,created_at) VALUES (?,?,?,?,?)', [id, 'direct', '', req.user.id, Date.now()]);
  await run('INSERT INTO members (conv_id,user_id) VALUES (?,?)', [id, req.user.id]);
  await run('INSERT INTO members (conv_id,user_id) VALUES (?,?)', [id, u.id]);
  res.json({ chat: await one('SELECT id,type,title,username FROM conversations WHERE id=?', [id]) });
});

app.post('/api/chats/group', auth, async (req, res) => {
  const title = sanitizeText(req.body.title, 60) || 'Grupo';
  const username = cleanUsername(req.body.username);
  const type = req.body.is_channel ? 'channel' : 'group';
  if (username && await one('SELECT id FROM conversations WHERE username=?', [username])) return res.status(409).json({ error: 'taken' });
  const id = uuidv4();
  await run('INSERT INTO conversations (id,type,title,username,created_by,created_at) VALUES (?,?,?,?,?,?)',
    [id, type, title, username || null, req.user.id, Date.now()]);
  await run('INSERT INTO members (conv_id,user_id,role) VALUES (?,?,?)', [id, req.user.id, 'owner']);
  const add = Array.isArray(req.body.members) ? req.body.members.slice(0, 200) : [];
  for (const un of add) {
    const usr = await one('SELECT id FROM users WHERE username=?', [cleanUsername(un)]);
    if (usr && usr.id !== req.user.id) await run('INSERT OR IGNORE INTO members (conv_id,user_id) VALUES (?,?)', [id, usr.id]);
  }
  res.json({ chat: await one('SELECT id,type,title,username FROM conversations WHERE id=?', [id]) });
});

app.get('/api/chats/:id/messages', auth, requireMember, async (req, res) => {
  const msgs = await q(`SELECT m.id,m.conv_id,m.kind,m.text,m.media_url,m.duration_sec,m.created_at,
    u.name AS sender_name, u.username AS sender_username FROM messages m
    LEFT JOIN users u ON u.id=m.sender_id WHERE m.conv_id=? ORDER BY m.created_at ASC LIMIT 500`, [req.params.id]);
  const conv = await one('SELECT id,type,title,username FROM conversations WHERE id=?', [req.params.id]);
  res.json({ conv, messages: msgs });
});

const MSG_KINDS = new Set(['text', 'photo', 'video', 'voice', 'doc', 'sticker', 'gif']);
app.post('/api/chats/:id/messages', auth, requireMember, async (req, res) => {
  const kind = MSG_KINDS.has(req.body.kind) ? req.body.kind : 'text';
  const text = sanitizeText(req.body.text, 4000);
  let media_url = sanitizeText(req.body.media_url, 300);
  if (media_url && !media_url.startsWith('/uploads/')) media_url = ''; // solo archivos propios
  const duration_sec = Math.max(0, Math.min(3600, parseInt(req.body.duration_sec) || 0));
  if (kind === 'text' && !text) return res.status(400).json({ error: 'empty' });
  if (kind !== 'text' && !media_url && !text) return res.status(400).json({ error: 'empty' });
  const id = uuidv4();
  await run('INSERT INTO messages (id,conv_id,sender_id,kind,text,media_url,duration_sec,created_at) VALUES (?,?,?,?,?,?,?,?)',
    [id, req.params.id, req.user.id, kind, text, media_url, duration_sec, Date.now()]);
  const msg = await one(`SELECT m.id,m.conv_id,m.kind,m.text,m.media_url,m.duration_sec,m.created_at,
    u.name AS sender_name, u.username AS sender_username FROM messages m
    LEFT JOIN users u ON u.id=m.sender_id WHERE m.id=?`, [id]);
  io.to('conv:' + req.params.id).emit('message:new', msg);
  handleBotCommands(req.params.id, msg).catch(() => {});
  res.json({ message: msg });
});

// ---------- Historias ----------
app.get('/api/stories', auth, async (req, res) => {
  const rows = await q(`SELECT s.id,s.media_url,s.caption,s.created_at,u.name,u.username FROM stories s
    JOIN users u ON u.id=s.user_id WHERE s.expires_at > ? ORDER BY s.created_at DESC LIMIT 100`, [Date.now()]);
  res.json({ stories: rows });
});
app.post('/api/stories', auth, async (req, res) => {
  let media_url = sanitizeText(req.body.media_url, 300);
  if (!media_url.startsWith('/uploads/')) return res.status(400).json({ error: 'bad_media' });
  const caption = sanitizeText(req.body.caption, 200);
  const id = uuidv4();
  const now = Date.now();
  await run('INSERT INTO stories (id,user_id,media_url,caption,created_at,expires_at) VALUES (?,?,?,?,?,?)',
    [id, req.user.id, media_url, caption, now, now + 24 * 3600 * 1000]);
  const st = await one(`SELECT s.id,s.media_url,s.caption,s.created_at,u.name,u.username FROM stories s JOIN users u ON u.id=s.user_id WHERE s.id=?`, [id]);
  io.emit('story:new', st);
  res.json({ story: st });
});

// ---------- Llamadas ----------
app.get('/api/calls', auth, async (req, res) => {
  const rows = await q(`SELECT c.id,c.kind,c.status,c.started_at,c.ended_at,u1.name AS caller_name,u2.name AS callee_name FROM calls c
    LEFT JOIN users u1 ON u1.id=c.caller_id LEFT JOIN users u2 ON u2.id=c.callee_id
    WHERE c.caller_id=? OR c.callee_id=? ORDER BY c.started_at DESC LIMIT 50`, [req.user.id, req.user.id]);
  res.json({ calls: rows });
});

// ---------- Bots ----------
app.post('/api/bots', auth, async (req, res) => {
  const name = sanitizeText(req.body.name, 40) || 'Mi Bot';
  let username = cleanUsername(req.body.username);
  if (!username.endsWith('bot')) username += 'bot';
  if (username.length < 4) return res.status(400).json({ error: 'invalid' });
  if (await one('SELECT id FROM bots WHERE username=?', [username])) return res.status(409).json({ error: 'taken' });
  const id = uuidv4();
  const token = genBotToken();
  await run('INSERT INTO bots (id,owner_id,name,username,token,created_at) VALUES (?,?,?,?,?,?)',
    [id, req.user.id, name, username, token, Date.now()]);
  res.json({ bot: { id, name, username, token } });
});
app.get('/api/bots', auth, async (req, res) => {
  const rows = await q('SELECT id,name,username,token,created_at FROM bots WHERE owner_id=?', [req.user.id]);
  res.json({ bots: rows });
});
app.post('/api/bot/:token/sendMessage', authLimiter, async (req, res) => {
  const token = sanitizeText(req.params.token, 60);
  const bot = await one('SELECT * FROM bots WHERE token=?', [token]);
  if (!bot) return res.status(401).json({ ok: false, error: 'bad_token' });
  const chatId = sanitizeText(req.body.chat_id, 60);
  const text = sanitizeText(req.body.text, 4000);
  if (!text) return res.status(400).json({ ok: false, error: 'empty' });
  const mb = await one('SELECT * FROM members WHERE conv_id=?', [chatId]);
  if (!mb) return res.status(404).json({ ok: false, error: 'chat_not_found' });
  const id = uuidv4();
  await run('INSERT INTO messages (id,conv_id,sender_id,kind,text,created_at) VALUES (?,?,?,?,?,?)',
    [id, chatId, 'bot:' + bot.id, 'text', '🤖 ' + bot.name + ': ' + text, Date.now()]);
  const msg = await one('SELECT id,conv_id,kind,text,created_at FROM messages WHERE id=?', [id]);
  msg.sender_name = bot.name; msg.sender_username = bot.username;
  io.to('conv:' + chatId).emit('message:new', msg);
  res.json({ ok: true, message: msg });
});
async function handleBotCommands(convId, msg) {
  if (!msg.text || !msg.text.startsWith('/')) return;
  const bots = await q('SELECT * FROM bots LIMIT 5');
  if (!bots.length) return;
  const [cmd, ...rest] = msg.text.slice(1).split(' ');
  const arg = rest.join(' ');
  let reply = null;
  const c = cmd.toLowerCase();
  if (c === 'ayuda') reply = 'Comandos: /ayuda /eco <texto> /hora /fecha /sumar <a> <b> /dado /moneda';
  else if (c === 'eco') reply = sanitizeText(arg, 500) || '...';
  else if (c === 'hora') reply = '🕐 ' + new Date().toLocaleTimeString();
  else if (c === 'fecha') reply = '📅 ' + new Date().toLocaleDateString();
  else if (c === 'sumar') { const n = arg.split(/\s+/).map(Number).filter(x => !isNaN(x)); reply = n.length >= 2 ? `🧮 ${n[0]} + ${n[1]} = ${n[0] + n[1]}` : 'Uso: /sumar 2 3'; }
  else if (c === 'dado') reply = '🎲 ' + (1 + Math.floor(Math.random() * 6));
  else if (c === 'moneda') reply = Math.random() < 0.5 ? '🪙 Cara' : '🪙 Cruz';
  if (!reply) return;
  const bot = bots[0];
  const id = uuidv4();
  await run('INSERT INTO messages (id,conv_id,sender_id,kind,text,created_at) VALUES (?,?,?,?,?,?)',
    [id, convId, 'bot:' + bot.id, 'text', reply, Date.now()]);
  const m = await one('SELECT id,conv_id,kind,text,created_at FROM messages WHERE id=?', [id]);
  m.sender_name = bot.name; m.sender_username = bot.username;
  io.to('conv:' + convId).emit('message:new', m);
}

// ---------- Socket.io ----------
io.on('connection', (socket) => {
  socket.on('auth', async ({ token }) => {
    const tk = sanitizeText(token, 100);
    const s = await one('SELECT * FROM sessions WHERE token=?', [tk]);
    if (!s || s.expires_at < Date.now()) return socket.emit('auth:error');
    socket.userId = s.user_id;
    socket.join('user:' + s.user_id);
    const mbs = await q('SELECT conv_id FROM members WHERE user_id=?', [s.user_id]);
    mbs.forEach(m => socket.join('conv:' + m.conv_id));
    socket.emit('auth:ok');
  });
  socket.on('typing', ({ conv_id }) => {
    if (socket.userId) socket.to('conv:' + sanitizeText(conv_id, 60)).emit('typing', { conv_id, user_id: socket.userId });
  });
  socket.on('call:invite', async ({ to, kind }) => {
    if (!socket.userId) return;
    const callee = await one('SELECT id FROM users WHERE id=?', [sanitizeText(to, 60)]);
    if (!callee || callee.id === socket.userId) return;
    const id = uuidv4();
    await run('INSERT INTO calls (id,caller_id,callee_id,kind,status,started_at) VALUES (?,?,?,?,?,?)',
      [id, socket.userId, callee.id, kind === 'video' ? 'video' : 'voice', 'ringing', Date.now()]);
    const caller = await one('SELECT name,username,photo FROM users WHERE id=?', [socket.userId]);
    io.to('user:' + callee.id).emit('call:incoming', { id, from: socket.userId, caller, kind: kind === 'video' ? 'video' : 'voice' });
  });
  socket.on('call:signal', ({ to, data }) => {
    if (!socket.userId) return;
    io.to('user:' + sanitizeText(to, 60)).emit('call:signal', { from: socket.userId, data });
  });
  const ownCall = async (id) => {
    const c = await one('SELECT * FROM calls WHERE id=?', [sanitizeText(id, 60)]);
    return (c && (c.caller_id === socket.userId || c.callee_id === socket.userId)) ? c : null;
  };
  socket.on('call:accept', async ({ id, to }) => { if (await ownCall(id)) { await run("UPDATE calls SET status='active' WHERE id=?", [id]); io.to('user:' + sanitizeText(to, 60)).emit('call:accepted', { id }); } });
  socket.on('call:reject', async ({ id, to }) => { if (await ownCall(id)) { await run("UPDATE calls SET status='rejected', ended_at=? WHERE id=?", [Date.now(), id]); io.to('user:' + sanitizeText(to, 60)).emit('call:rejected', { id }); } });
  socket.on('call:end', async ({ id, to }) => { if (await ownCall(id)) { await run("UPDATE calls SET status='ended', ended_at=? WHERE id=?", [Date.now(), id]); io.to('user:' + sanitizeText(to, 60)).emit('call:ended', { id }); } });
});

app.get('/api/health', (req, res) => res.json({ ok: true, app: 'BIN Y VUELTAS RD' }));
// 15/16. 404: la API responde 404 JSON; la SPA se sirve para rutas de la app
app.use('/api/', (req, res) => res.status(404).json({ error: 'not_found' }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

server.listen(PORT, () => console.log('BIN Y VUELTAS RD en puerto ' + PORT));
