// BIN Y VUELTAS RD - Frontend
const I18N = {
es:{login:"Entrar",register:"Registrarse",your_name:"Tu nombre",create_account:"Crear cuenta",your_key:"Tu clave única (guárdala):",copy:"Copiar",enter:"Entrar",unique_key:"Clave única",search:"Buscar",all:"Todos",personal:"Personales",groups:"Grupos",channels:"Canales",contacts:"Contactos",calls:"Llamadas",chats:"Chats",settings:"Ajustes",my_profile:"Mi perfil",saved:"Mensajes guardados",my_bots:"Mis bots",my_key:"Mi clave única",logout:"Cerrar sesión",invite:"Invitar amigos",missed:"Perdidas",new_call:"Nueva llamada",photo:"Foto",video:"Video",file:"Archivo",message:"Mensaje",calling:"Llamando…",accept:"Aceptar",reject:"Rechazar",no_chats:"Aún no tienes chats",new_message:"Nuevo mensaje",send:"Enviar",privacy:"Privacidad",terms:"Términos",cookie_text:"Usamos almacenamiento local en tu dispositivo para tu sesión e idioma.",accept_cookies:"Aceptar",decline:"Rechazar"},
en:{login:"Log in",register:"Sign up",your_name:"Your name",create_account:"Create account",your_key:"Your unique key (save it):",copy:"Copy",enter:"Enter",unique_key:"Unique key",search:"Search",all:"All",personal:"Personal",groups:"Groups",channels:"Channels",contacts:"Contacts",calls:"Calls",chats:"Chats",settings:"Settings",my_profile:"My profile",saved:"Saved Messages",my_bots:"My bots",my_key:"My unique key",logout:"Log out",invite:"Invite friends",missed:"Missed",new_call:"New call",photo:"Photo",video:"Video",file:"File",message:"Message",calling:"Calling…",accept:"Accept",reject:"Decline",no_chats:"You don't have any chats yet",new_message:"New message",send:"Send",privacy:"Privacy",terms:"Terms",cookie_text:"We use local storage on your device for your session and language.",accept_cookies:"Accept",decline:"Decline"},
fr:{login:"Se connecter",register:"S'inscrire",your_name:"Votre nom",create_account:"Créer un compte",your_key:"Votre clé unique (gardez-la) :",copy:"Copier",enter:"Entrer",unique_key:"Clé unique",search:"Rechercher",all:"Tous",personal:"Personnels",groups:"Groupes",channels:"Canaux",contacts:"Contacts",calls:"Appels",chats:"Discussions",settings:"Réglages",my_profile:"Mon profil",saved:"Messages enregistrés",my_bots:"Mes bots",my_key:"Ma clé unique",logout:"Déconnexion",invite:"Inviter des amis",missed:"Manqués",new_call:"Nouvel appel",photo:"Photo",video:"Vidéo",file:"Fichier",message:"Message",calling:"Appel…",accept:"Accepter",reject:"Refuser",no_chats:"Vous n'avez pas encore de discussions",new_message:"Nouveau message",send:"Envoyer",privacy:"Confidentialité",terms:"Conditions",cookie_text:"Nous utilisons le stockage local de votre appareil pour votre session et votre langue.",accept_cookies:"Accepter",decline:"Refuser"},
pt:{login:"Entrar",register:"Cadastrar",your_name:"Seu nome",create_account:"Criar conta",your_key:"Sua chave única (guarde-a):",copy:"Copiar",enter:"Entrar",unique_key:"Chave única",search:"Buscar",all:"Todos",personal:"Pessoais",groups:"Grupos",channels:"Canais",contacts:"Contatos",calls:"Chamadas",chats:"Conversas",settings:"Ajustes",my_profile:"Meu perfil",saved:"Mensagens salvas",my_bots:"Meus bots",my_key:"Minha chave única",logout:"Sair",invite:"Convidar amigos",missed:"Perdidas",new_call:"Nova chamada",photo:"Foto",video:"Vídeo",file:"Arquivo",message:"Mensagem",calling:"Chamando…",accept:"Aceitar",reject:"Recusar",no_chats:"Você ainda não tem conversas",new_message:"Nova mensagem",send:"Enviar",privacy:"Privacidade",terms:"Termos",cookie_text:"Usamos armazenamento local no seu dispositivo para sua sessão e idioma.",accept_cookies:"Aceitar",decline:"Recusar"},
de:{login:"Anmelden",register:"Registrieren",your_name:"Dein Name",create_account:"Konto erstellen",your_key:"Dein einzigartiger Schlüssel (speichern):",copy:"Kopieren",enter:"Eintreten",unique_key:"Schlüssel",search:"Suchen",all:"Alle",personal:"Persönlich",groups:"Gruppen",channels:"Kanäle",contacts:"Kontakte",calls:"Anrufe",chats:"Chats",settings:"Einstellungen",my_profile:"Mein Profil",saved:"Gespeicherte Nachrichten",my_bots:"Meine Bots",my_key:"Mein Schlüssel",logout:"Abmelden",invite:"Freunde einladen",missed:"Verpasst",new_call:"Neuer Anruf",photo:"Foto",video:"Video",file:"Datei",message:"Nachricht",calling:"Anruf…",accept:"Annehmen",reject:"Ablehnen",no_chats:"Du hast noch keine Chats",new_message:"Neue Nachricht",send:"Senden",privacy:"Datenschutz",terms:"Bedingungen",cookie_text:"Wir nutzen lokalen Speicher auf deinem Gerät für Sitzung und Sprache.",accept_cookies:"Akzeptieren",decline:"Ablehnen"},
it:{login:"Accedi",register:"Registrati",your_name:"Il tuo nome",create_account:"Crea account",your_key:"La tua chiave unica (salvala):",copy:"Copia",enter:"Entra",unique_key:"Chiave unica",search:"Cerca",all:"Tutti",personal:"Personali",groups:"Gruppi",channels:"Canali",contacts:"Contatti",calls:"Chiamate",chats:"Chat",settings:"Impostazioni",my_profile:"Il mio profilo",saved:"Messaggi salvati",my_bots:"I miei bot",my_key:"La mia chiave",logout:"Esci",invite:"Invita amici",missed:"Perse",new_call:"Nuova chiamata",photo:"Foto",video:"Video",file:"File",message:"Messaggio",calling:"Chiamata…",accept:"Accetta",reject:"Rifiuta",no_chats:"Non hai ancora chat",new_message:"Nuovo messaggio",send:"Invia",privacy:"Privacy",terms:"Termini",cookie_text:"Usiamo lo spazio locale sul tuo dispositivo per sessione e lingua.",accept_cookies:"Accetta",decline:"Rifiuta"}
};
let LANG = (localStorage.getItem('bv_lang') || (navigator.language || 'es').slice(0,2)).toLowerCase();
if (!I18N[LANG]) LANG = 'es';
const t = k => (I18N[LANG] && I18N[LANG][k]) || I18N.es[k] || k;
function applyI18n(){ document.querySelectorAll('[data-i18n]').forEach(e=>e.textContent=t(e.dataset.i18n)); document.querySelectorAll('[data-i18n-ph]').forEach(e=>e.placeholder=t(e.dataset.i18nPh)); document.documentElement.lang=LANG; }

const $ = id => document.getElementById(id);
const api = async (m, p, body) => {
  const h = { 'Content-Type':'application/json' };
  const tok = localStorage.getItem('bv_token');
  if (tok) h['Authorization'] = 'Bearer ' + tok;
  const r = await fetch(p, { method:m, headers:h, body: body?JSON.stringify(body):undefined });
  return r.json();
};
let ME=null, SOCKET=null, CHATS=[], CUR=null, FOLDER='all', PEER=null, PC=null, LOCALSTREAM=null, CALLID=null, CALLTIMER=null, CALLSEC=0, RECORDER=null, RECCHUNKS=[];

const EMOJIS="😀😁😂🤣😊😍😎🤔😴😭😡👍👎🙏👏💪🔥❤️💔🎉🎁⚽🚗✈️🍕☕🌹🐶🐱🦁🌙⭐🌈".split(/(\uD83C[\uDDE6-\uDDFF]\uD83C[\uDDE6-\uDDFF]|.)/u).filter(x=>x&&x.trim());
const STICKERS=["🐱","🐶","🦊","🐼","🦁","🐸","🐵","🦄","🐝","🐢","🎭","💃","🕺","🎸","⚽","🏀","🚀","🌈","🔥","💯","❤️","💔","😂","😎","🤖","👻","🎃","🎄","🎁","🍕"];
const GIFS=[["🎁","Un regalo para ti"],["🎉","Fiesta"],["😂","Risa"],["❤️","Amor"],["👏","Bravo"],["🔥","En llamas"],["⚽","Gol"],["🌈","Colores"],["🐱","Gatito"],["🚀","Despegue"],["💃","Baile"],["☕","Café"]];

function avatarHTML(u, cls){ const c=cls||'avatar'; if(u&&u.photo) return `<div class="${c}"><img src="${u.photo}"></div>`; const n=(u&&(u.name||u.username||'?')).trim().charAt(0).toUpperCase(); return `<div class="${c}">${n}</div>`; }
function esc(s){ return String(s||'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function timeFmt(ts){ const d=new Date(ts); return d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}); }

function showModal(html){ $('modal-card').innerHTML=html; $('modal').classList.remove('hidden'); }
function closeModal(){ $('modal').classList.add('hidden'); }
$('modal').addEventListener('click', e=>{ if(e.target.id==='modal') closeModal(); });

// ---------- Auth ----------
$('tab-login').onclick=()=>{ $('tab-login').classList.add('active'); $('tab-register').classList.remove('active'); $('form-login').classList.remove('hidden'); $('form-register').classList.add('hidden'); };
$('tab-register').onclick=()=>{ $('tab-register').classList.add('active'); $('tab-login').classList.remove('active'); $('form-register').classList.remove('hidden'); $('form-login').classList.add('hidden'); };
$('btn-register').onclick=async()=>{
  const r=await api('POST','/api/register',{name:$('reg-name').value, username:$('reg-user').value, website:$('reg-website').value});
  if(r.error){ $('auth-error').textContent = r.error==='taken' ? '@usuario en uso' : 'Completa nombre y @usuario (mín. 3)'; return; }
  localStorage.setItem('bv_token', r.token);
  $('reg-key').textContent=r.key; $('reg-key-box').classList.remove('hidden');
  window._pendingUser=r.user;
};
$('btn-copy-key').onclick=()=>{ navigator.clipboard.writeText($('reg-key').textContent); };
$('btn-enter-after-reg').onclick=()=>{ ME=window._pendingUser; enterApp(); };
$('btn-login').onclick=async()=>{
  const r=await api('POST','/api/login',{username:$('login-user').value, key:$('login-key').value, website:$('login-website').value});
  if(r.error){ $('auth-error').textContent='Usuario o clave incorrectos'; return; }
  localStorage.setItem('bv_token', r.token); ME=r.user; enterApp();
};

async function enterApp(){
  $('auth-screen').classList.add('hidden'); $('main-screen').classList.remove('hidden');
  $('drawer-name').textContent=ME.name; $('drawer-user').textContent='@'+ME.username;
  $('drawer-avatar').outerHTML=avatarHTML(ME,'avatar big').replace('class="avatar big"','class="avatar big" id="drawer-avatar"');
  connectSocket(); loadChats(); loadStories(); applyI18n();
}
function connectSocket(){
  SOCKET=io(); SOCKET.emit('auth',{token:localStorage.getItem('bv_token')});
  SOCKET.on('message:new', m=>{ if(CUR&&m.conv_id===CUR.id) addMsg(m); loadChats(true); });
  SOCKET.on('typing', d=>{ if(CUR&&d.conv_id===CUR.id){ const el=$('typing-indicator'); el.textContent='…'; el.classList.remove('hidden'); clearTimeout(window._tt); window._tt=setTimeout(()=>el.classList.add('hidden'),1500);} });
  SOCKET.on('story:new', ()=>loadStories());
  SOCKET.on('call:incoming', onIncomingCall);
  SOCKET.on('call:signal', async ({data})=>{ if(!PC) return; if(data.sdp){ await PC.setRemoteDescription(data.sdp); if(data.sdp.type==='offer'){ const a=await PC.createAnswer(); await PC.setLocalDescription(a); SOCKET.emit('call:signal',{to:PEER,data:{sdp:PC.localDescription}});} } else if(data.ice){ PC.addIceCandidate(data.ice).catch(()=>{}); } });
  SOCKET.on('call:accepted', ()=>{ $('call-status').textContent='●'; startCallTimer(); });
  SOCKET.on('call:rejected', ()=>{ endCallUI(); });
  SOCKET.on('call:ended', ()=>{ endCallUI(); });
}

// ---------- Chats ----------
async function loadChats(quiet){
  const r=await api('GET','/api/chats'); if(r.chats) CHATS=r.chats;
  const q=$('search-chats').value.toLowerCase();
  const list=$('chat-list'); list.innerHTML='';
  const shown=CHATS.filter(c=>{
    if(FOLDER!=='all'){ if(FOLDER==='direct'&&c.type!=='direct')return false; if(FOLDER==='group'&&c.type!=='group')return false; if(FOLDER==='channel'&&c.type!=='channel')return false; }
    if(q && !(c.title+' '+(c.username||'')).toLowerCase().includes(q)) return false;
    return true;
  });
  if(!shown.length && !quiet){ list.innerHTML=`<div style="text-align:center;padding:40px 20px;color:var(--muted)"><div style="font-size:54px">🐣</div><p>${t('no_chats')}</p><button class="btn-primary" style="max-width:220px" onclick="openNewChat()">${t('new_message')}</button></div>`; return; }
  shown.forEach(c=>{
    let title=c.title, sub='@'+(c.username||'');
    if(c.type==='direct'){ const o=c.other_name||''; title=o||sub; }
    const prev=c.last_kind==='photo'?'📷 Foto':c.last_kind==='video'?'🎬 Video':c.last_kind==='voice'?'🎤 Nota de voz':c.last_kind==='sticker'?'🎭 Sticker':c.last_kind==='gif'?'🎁 GIF':(c.last_text||'');
    const b=document.createElement('button'); b.className='chat-row';
    b.innerHTML=`${avatarHTML({name:title})}<div class="info"><div class="name"><span>${esc(title)}</span><time>${c.last_at?timeFmt(c.last_at):''}</time></div><div class="prev">${esc(prev)}</div></div>`;
    b.onclick=()=>openChat(c.id); list.appendChild(b);
  });
}
document.querySelectorAll('.folders button').forEach(b=>b.onclick=()=>{ document.querySelectorAll('.folders button').forEach(x=>x.classList.remove('active')); b.classList.add('active'); FOLDER=b.dataset.f; loadChats(); });
$('search-chats').oninput=()=>loadChats();
window.openNewChat=openNewChat;
function openNewChat(){
  showModal(`<h3>✎ ${t('new_message')}</h3>
    <button class="btn-primary" onclick="newGroup(false)">👥 ${t('groups')}</button>
    <button class="btn-primary" onclick="newGroup(true)">📣 ${t('channels')}</button>
    <input id="nc-user" placeholder="@usuario"><button class="btn-primary" onclick="newDirect()">${t('send')}</button>
    <button class="btn-danger" onclick="closeModal()">✕</button>`);
}
window.closeModal=closeModal;
window.newDirect=async()=>{ const u=$('nc-user').value; const r=await api('POST','/api/chats/direct',{username:u}); if(r.chat){closeModal(); openChat(r.chat.id);} };
window.newGroup=async(isCh)=>{ const title=prompt(isCh?'Nombre del canal':'Nombre del grupo'); if(!title) return; const un=prompt('@usuario público (opcional)')||''; const r=await api('POST','/api/chats/group',{title,username:un,is_channel:isCh}); if(r.chat){closeModal(); loadChats(); openChat(r.chat.id);} };

async function openChat(id){
  const r=await api('GET',`/api/chats/${id}/messages`); if(!r.conv) return;
  CUR=r.conv;
  // nombre para directos: buscar al otro miembro
  let title=CUR.title||'', sub=CUR.username?'@'+CUR.username:'';
  $('chat-title').innerHTML=`<div class="t">${esc(title)||esc(sub)||'Chat'}</div><div class="s">${esc(sub)}</div>`;
  $('main-screen').classList.add('hidden'); $('chat-screen').classList.remove('hidden');
  $('messages').innerHTML=''; r.messages.forEach(addMsg);
  $('messages').scrollTop=99999;
}
function addMsg(m){
  const me = ME && m.sender_id===ME.id;
  const d=document.createElement('div'); d.className='msg '+(me?'me':'them');
  let body='';
  if(m.kind==='photo') body=`<img src="${m.media_url}" alt="Foto enviada en el chat" loading="lazy" onclick="window.open('${m.media_url}')">`;
  else if(m.kind==='video') body=`<video src="${m.media_url}" controls preload="metadata"></video>`;
  else if(m.kind==='voice') body=`<audio src="${m.media_url}" controls></audio> ${m.duration_sec||''}s`;
  else if(m.kind==='doc') body=`📄 <a href="${m.media_url}" target="_blank" style="color:inherit">Archivo</a>`;
  else if(m.kind==='sticker') body=`<span class="sticker-big">${esc(m.text)}</span>`;
  else if(m.kind==='gif') body=`<button class="gif-card">🎁 GIF<br><b>${esc(m.text)}</b></button>`;
  else body=esc(m.text);
  const snd = (!me && m.sender_name) ? `<div class="sender">${esc(m.sender_name)}</div>` : '';
  d.innerHTML=`${snd}${body}<div class="meta">${timeFmt(m.created_at)} ${me?'✓✓':''}</div>`;
  $('messages').appendChild(d); $('messages').scrollTop=99999;
}
$('btn-back').onclick=()=>{ CUR=null; $('chat-screen').classList.add('hidden'); $('main-screen').classList.remove('hidden'); loadChats(); };
$('btn-chat-info').onclick=()=>{ const p=$('chat-profile-panel'); const open=p.classList.toggle('open');
  if(open&&CUR) p.innerHTML=`<h3>${esc(CUR.title||'@'+(CUR.username||''))}</h3><p style="color:var(--muted)">${CUR.type==='group'?'👥 Grupo':CUR.type==='channel'?'📣 Canal':CUR.type==='saved'?'🔖':'💬'} ${CUR.username?'@'+esc(CUR.username):''}</p><button class="btn-danger" onclick="document.getElementById('chat-profile-panel').classList.remove('open')">✕</button>`; };

async function sendMsg(kind,text,media_url,duration_sec){
  if(!CUR) return;
  await api('POST',`/api/chats/${CUR.id}/messages`,{kind,text:text||'',media_url:media_url||'',duration_sec:duration_sec||0});
  $('msg-input').value=''; $('btn-send').classList.add('hidden'); $('btn-voice').classList.remove('hidden');
}
$('btn-send').onclick=()=>{ const v=$('msg-input').value.trim(); if(v) sendMsg('text',v); };
$('msg-input').oninput=e=>{ const v=e.target.value.trim(); $('btn-send').classList.toggle('hidden',!v); $('btn-voice').classList.toggle('hidden',!!v); if(CUR&&v) SOCKET.emit('typing',{conv_id:CUR.id}); };
$('msg-input').onkeydown=e=>{ if(e.key==='Enter'){ const v=e.target.value.trim(); if(v) sendMsg('text',v);} };

// Adjuntos
$('btn-attach').onclick=()=>{ $('attach-panel').classList.toggle('hidden'); $('emoji-panel').classList.add('hidden'); };
document.querySelectorAll('#attach-panel button').forEach(b=>b.onclick=()=>{ const k=b.dataset.a; $('file-input').accept=k==='photo'?'image/*':k==='video'?'video/*':'*/*'; $('file-input').dataset.kind=k; $('file-input').click(); $('attach-panel').classList.add('hidden'); });
$('file-input').onchange=async e=>{
  const f=e.target.files[0]; if(!f) return;
  const fd=new FormData(); fd.append('file',f);
  const r=await fetch('/api/upload',{method:'POST',headers:{'Authorization':'Bearer '+localStorage.getItem('bv_token')},body:fd}).then(r=>r.json());
  if(r.url){ const k=e.target.dataset.kind; sendMsg(k==='photo'?'photo':k==='video'?'video':'doc','',r.url); }
  e.target.value='';
};
// Emojis / stickers / gifs
$('btn-emoji').onclick=()=>{ $('emoji-panel').classList.toggle('hidden'); $('attach-panel').classList.add('hidden'); renderEmoji('emoji'); };
document.querySelectorAll('.emoji-tabs button').forEach(b=>b.onclick=()=>{ document.querySelectorAll('.emoji-tabs button').forEach(x=>x.classList.remove('active')); b.classList.add('active'); renderEmoji(b.dataset.e); });
function renderEmoji(kind){
  const g=$('emoji-grid'); g.innerHTML='';
  const add=(label,fn)=>{ const b=document.createElement('button'); b.innerHTML=label; b.onclick=fn; g.appendChild(b); };
  if(kind==='emoji') EMOJIS.forEach(e=>add(e,()=>{ $('msg-input').value+=e; $('msg-input').oninput({target:$('msg-input')}); }));
  else if(kind==='stickers') STICKERS.forEach(s=>add(`<span style="font-size:44px">${s}</span>`,()=>sendMsg('sticker',s)));
  else GIFS.forEach(([e,n])=>add(`<span style="font-size:40px">${e}</span><div style="font-size:11px">${n}</div>`,()=>sendMsg('gif',n)));
}
// Nota de voz
$('btn-voice').onclick=async()=>{
  if(RECORDER){ RECORDER.stop(); return; }
  try{
    LOCALSTREAM=await navigator.mediaDevices.getUserMedia({audio:true});
    RECORDER=new MediaRecorder(LOCALSTREAM); RECCHUNKS=[];
    RECORDER.ondataavailable=e=>RECCHUNKS.push(e.data);
    RECORDER.onstop=async()=>{
      const blob=new Blob(RECCHUNKS,{type:'audio/webm'});
      const fd=new FormData(); fd.append('file',blob,'nota.webm');
      const r=await fetch('/api/upload',{method:'POST',headers:{'Authorization':'Bearer '+localStorage.getItem('bv_token')},body:fd}).then(r=>r.json());
      if(r.url) sendMsg('voice','',r.url,Math.round(blob.size/16000)||3);
      LOCALSTREAM.getTracks().forEach(x=>x.stop()); RECORDER=null; $('btn-voice').textContent='🎤';
    };
    RECORDER.start(); $('btn-voice').textContent='⏹️';
  }catch(e){ alert('Sin acceso al micrófono'); }
};

// ---------- Historias ----------
async function loadStories(){
  const r=await api('GET','/api/stories'); const bar=$('stories-bar'); bar.innerHTML='';
  const mine=document.createElement('button'); mine.className='story-item';
  mine.innerHTML=`<div class="story-ring" style="background:#e5e5ea"><div class="avatar">＋</div></div><span>${t('my_profile').split(' ')[0]}</span>`;
  mine.onclick=()=>{ $('file-input').accept='image/*,video/*'; $('file-input').dataset.kind='story'; $('file-input').click(); };
  bar.appendChild(mine);
  (r.stories||[]).forEach(s=>{
    const b=document.createElement('button'); b.className='story-item';
    b.innerHTML=`<div class="story-ring">${avatarHTML({name:s.name,photo:s.photo})}</div><span>${esc(s.name.split(' ')[0])}</span>`;
    b.onclick=()=>viewStory(s); bar.appendChild(b);
  });
}
$('file-input').addEventListener('change', async e=>{
  if(e.target.dataset.kind!=='story') return;
  const f=e.target.files[0]; if(!f) return;
  const fd=new FormData(); fd.append('file',f);
  const r=await fetch('/api/upload',{method:'POST',headers:{'Authorization':'Bearer '+localStorage.getItem('bv_token')},body:fd}).then(r=>r.json());
  if(r.url){ const cap=prompt('Texto (opcional)')||''; await api('POST','/api/stories',{media_url:r.url,caption:cap}); loadStories(); }
  e.target.value=''; e.target.dataset.kind='';
}, true);
function viewStory(s){
  const v=document.createElement('div'); v.className='story-viewer';
  const isV=/\.(mp4|webm|mov)$/i.test(s.media_url);
  v.innerHTML=`<div class="story-progress"><i id="sp"></i></div><div class="story-head"><b>${esc(s.name)}</b><span>· 24h</span><button class="icon-btn" style="color:#fff" onclick="this.closest('.story-viewer').remove()">✕</button></div>
  ${isV?`<video src="${s.media_url}" autoplay playsinline preload="metadata"></video>`:`<img src="${s.media_url}" alt="Historia de ${esc(s.name)}">`}
  <p style="padding:0 16px">${esc(s.caption||'')}</p>`;
  document.body.appendChild(v);
  let w=0; const iv=setInterval(()=>{ w+=4; const bar=v.querySelector('#sp'); if(!bar){clearInterval(iv);return;} bar.style.width=w+'%'; if(w>=100){clearInterval(iv); v.remove();} },200);
}

// ---------- Llamadas ----------
async function loadCalls(){
  const r=await api('GET','/api/calls'); const l=$('calls-list'); l.innerHTML='';
  (r.calls||[]).forEach(c=>{
    const other=c.caller_id===ME.id?c.callee_name:c.caller_name;
    const d=document.createElement('div'); d.className='chat-row';
    d.innerHTML=`${avatarHTML({name:other})}<div class="info"><div class="name"><span>${esc(other||'?')}</span><time>${timeFmt(c.started_at)}</time></div><div class="prev">${c.kind==='video'?'🎥':'📞'} ${c.status}</div></div><button class="icon-btn" onclick="callUserByName('${esc(other||'')}')">📞</button>`;
    l.appendChild(d);
  });
}
$('btn-new-call').onclick=async()=>{ const u=prompt('@usuario para llamar'); if(u) callUserByName(u); };
window.callUserByName=async(u)=>{
  const r=await api('POST','/api/chats/direct',{username:u}); if(r.error||!r.chat) return alert('Usuario no encontrado');
  const msgs=await api('GET',`/api/chats/${r.chat.id}/messages`);
  const other=msgs.conv; // buscar otro miembro vía lista
  startCall(r.chat.id, false);
};
async function startCall(chatId, isVideo){
  // obtener el otro usuario del chat
  const r=await api('GET',`/api/chats/${chatId}/messages`);
  const ms=r.messages||[]; const otherId=(ms.find(m=>m.sender_id!==ME.id)||{}).sender_id;
  // si no hay mensajes, pedir @usuario
  let to=otherId;
  if(!to){ const u=prompt('@usuario para llamar'); if(!u) return; const d=await api('POST','/api/chats/direct',{username:u}); if(!d.chat) return; return startCall(d.chat.id,isVideo); }
  PEER=to; showCallUI('Saliente', isVideo, false);
  SOCKET.emit('call:invite',{to, kind:isVideo?'video':'voice'});
  if(isVideo) await setupPC(true);
}
$('btn-voice-call').onclick=()=>CUR&&startCall(CUR.id,false);
$('btn-video-call').onclick=()=>CUR&&startCall(CUR.id,true);
function showCallUI(name,isVideo,incoming,caller){
  $('main-screen').classList.add('hidden'); $('chat-screen').classList.add('hidden'); $('call-screen').classList.remove('hidden');
  $('call-name').textContent=name; $('call-avatar').outerHTML=avatarHTML({name},'avatar big').replace('class="avatar big"','class="avatar big" id="call-avatar"');
  $('call-status').textContent=incoming?t('calling'):t('calling');
  $('incoming-btns').classList.toggle('hidden',!incoming);
  $('btn-camera').classList.toggle('hidden',!isVideo);
  $('local-video').classList.toggle('hidden',!isVideo); $('remote-video').classList.toggle('hidden',!isVideo);
  window._isVideo=isVideo;
}
async function onIncomingCall({id,from,caller,kind}){
  CALLID=id; PEER=from;
  showCallUI(caller.name+(caller.username?' @'+caller.username:''), kind==='video', true);
  $('btn-accept').onclick=async()=>{ $('incoming-btns').classList.add('hidden'); SOCKET.emit('call:accept',{id,to:PEER}); await setupPC(kind==='video'); startCallTimer(); };
  $('btn-reject').onclick=()=>{ SOCKET.emit('call:reject',{id,to:PEER}); endCallUI(); };
}
async function setupPC(isVideo){
  PC=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});
  try{
    LOCALSTREAM=await navigator.mediaDevices.getUserMedia({audio:true,video:isVideo});
    LOCALSTREAM.getTracks().forEach(tr=>PC.addTrack(tr,LOCALSTREAM));
    if(isVideo){ $('local-video').srcObject=LOCALSTREAM; }
  }catch(e){}
  PC.ontrack=e=>{ $('remote-video').srcObject=e.streams[0]; };
  PC.onicecandidate=e=>{ if(e.candidate) SOCKET.emit('call:signal',{to:PEER,data:{ice:e.candidate}}); };
  const offer=await PC.createOffer(); await PC.setLocalDescription(offer);
  SOCKET.emit('call:signal',{to:PEER,data:{sdp:PC.localDescription}});
}
function startCallTimer(){ CALLSEC=0; clearInterval(CALLTIMER); CALLTIMER=setInterval(()=>{ CALLSEC++; $('call-timer').textContent=String(Math.floor(CALLSEC/60)).padStart(2,'0')+':'+String(CALLSEC%60).padStart(2,'0'); },1000); }
function endCallUI(){
  clearInterval(CALLTIMER); if(CALLID&&PEER) SOCKET.emit('call:end',{id:CALLID,to:PEER});
  if(PC){PC.close();PC=null;} if(LOCALSTREAM){LOCALSTREAM.getTracks().forEach(x=>x.stop());LOCALSTREAM=null;}
  CALLID=null; PEER=null; $('call-screen').classList.add('hidden'); $('main-screen').classList.remove('hidden');
}
$('btn-hangup').onclick=endCallUI;
$('btn-mute').onclick=e=>{ if(!LOCALSTREAM) return; const a=LOCALSTREAM.getAudioTracks()[0]; a.enabled=!a.enabled; e.target.style.opacity=a.enabled?1:.4; };
$('btn-camera').onclick=e=>{ if(!LOCALSTREAM) return; const v=LOCALSTREAM.getVideoTracks()[0]; if(v){v.enabled=!v.enabled; e.target.style.opacity=v.enabled?1:.4;} };

// ---------- Drawer / tabs / ajustes ----------
$('btn-menu').onclick=()=>{ $('drawer').classList.add('open'); $('drawer-overlay').classList.remove('hidden'); };
$('drawer-overlay').onclick=closeDrawer;
function closeDrawer(){ $('drawer').classList.remove('open'); $('drawer-overlay').classList.add('hidden'); }
document.querySelectorAll('#drawer nav button').forEach(b=>b.onclick=()=>{ closeDrawer(); drawerAction(b.dataset.act); });
async function drawerAction(a){
  if(a==='logout'){ await api('POST','/api/logout'); localStorage.removeItem('bv_token'); location.reload(); }
  else if(a==='key'){ const k=prompt('Tu clave actual no se puede mostrar por seguridad. Copia tu clave guardada:'); }
  else if(a==='profile'||a==='settings'){ showTab('settings'); }
  else if(a==='saved'){ const r=await api('GET','/api/chats'); const s=(r.chats||[]).find(c=>c.type==='saved'); if(s) openChat(s.id); }
  else if(a==='bots'){ showBots(); }
}
document.querySelectorAll('#bottomnav button').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));
function showTab(name){
  document.querySelectorAll('#bottomnav button').forEach(x=>x.classList.toggle('active',x.dataset.tab===name));
  ['contacts','calls','chats','settings'].forEach(n=>$('view-'+n==='view-chats'?'chat-list':0));
  $('view-contacts').classList.toggle('hidden',name!=='contacts');
  $('view-calls').classList.toggle('hidden',name!=='calls');
  $('view-settings').classList.toggle('hidden',name!=='settings');
  $('chat-list').style.display=name==='chats'?'':'none';
  $('stories-bar').style.display=name==='chats'?'':'none';
  document.querySelector('.search-row').style.display=name==='chats'?'':'none';
  document.querySelector('.folders').style.display=name==='chats'?'':'none';
  if(name==='calls') loadCalls();
  if(name==='settings') renderSettings();
  if(name==='contacts') renderContacts();
}
async function renderContacts(){
  const l=$('contacts-list'); l.innerHTML=`<input id="c-search" placeholder="@usuario"><button class="btn-primary" id="c-go">${t('search')}</button><div id="c-res"></div>`;
  $('c-go').onclick=async()=>{ const u=$('c-search').value.replace('@',''); const r=await api('POST','/api/chats/direct',{username:u});
    if(r.chat){ openChat(r.chat.id); showTab('chats'); } else $('c-res').textContent='No encontrado'; };
}
function renderSettings(){
  const l=$('settings-list');
  const items=[
    ['📷','Foto de perfil','photo'],['👤','Mi perfil','profile'],['🔖',t('saved'),'saved'],['📞',t('calls'),'calls'],
    ['🌐','Idioma / Language','lang'],['🤖',t('my_bots'),'bots'],['🎁','Enviar un regalo','gift'],['🔑',t('my_key'),'key'],
    ['📜',t('privacy'),'privacy'],['📄',t('terms'),'terms'],['🚪',t('logout'),'logout']
  ];
  l.innerHTML=''; items.forEach(([e,n,k])=>{ const b=document.createElement('button'); b.innerHTML=`<span>${e}</span><span>${n}</span>`; b.onclick=()=>settingAction(k); l.appendChild(b); });
}
async function settingAction(k){
  if(k==='logout'){ await api('POST','/api/logout'); localStorage.removeItem('bv_token'); location.reload(); }
  else if(k==='photo'||k==='profile'){
    showModal(`<h3>👤 ${t('my_profile')}</h3><input id="p-name" value="${esc(ME.name)}" placeholder="${t('your_name')}"><input id="p-bio" value="${esc(ME.bio||'')}" placeholder="Bio"><input id="p-photo" value="${esc(ME.photo||'')}" placeholder="URL foto"><button class="btn-primary" id="p-up">📷 Subir foto</button><button class="btn-primary" id="p-save">${t('send')}</button><button class="btn-danger" onclick="closeModal()">✕</button>`);
    $('p-up').onclick=()=>{ $('file-input').accept='image/*'; $('file-input').dataset.kind='profile'; $('file-input').click(); };
    $('p-save').onclick=async()=>{ await api('POST','/api/profile',{name:$('p-name').value,bio:$('p-bio').value,photo:$('p-photo').value}); const m=await api('GET','/api/me'); ME=m.user; closeModal(); enterApp2(); };
  }
  else if(k==='lang'){
    showModal(`<h3>🌐 Idioma / Language</h3>${Object.keys(I18N).map(l=>`<button class="btn-primary" onclick="setLang('${l}')">${l.toUpperCase()} ${l===LANG?'✓':''}</button>`).join('')}<button class="btn-danger" onclick="closeModal()">✕</button>`);
  }
  else if(k==='bots'){ showBots(); }
  else if(k==='gift'){ showModal(`<h3>🎁</h3><div class="emoji-grid">${['🎁','💎','🌹','🍫','🧸','💝'].map(g=>`<button style="font-size:44px" onclick="sendGift('${g}')">${g}</button>`).join('')}</div><button class="btn-danger" onclick="closeModal()">✕</button>`); }
  else if(k==='saved'){ const r=await api('GET','/api/chats'); const s=(r.chats||[]).find(c=>c.type==='saved'); if(s){showTab('chats'); openChat(s.id);} }
  else if(k==='calls'){ showTab('calls'); }
  else if(k==='key'){ showModal(`<h3>🔑 ${t('my_key')}</h3><p>Tu clave se generó al registrarte. Si la perdiste, guarda la nueva:</p><button class="btn-primary" onclick="regenKey()">Generar nueva clave</button><button class="btn-danger" onclick="closeModal()">✕</button>`); }
  else if(k==='privacy'){ window.open('/privacidad.html','_blank'); }
  else if(k==='terms'){ window.open('/terminos.html','_blank'); }
}
window.setLang=l=>{ LANG=l; localStorage.setItem('bv_lang',l); location.reload(); };
window.sendGift=g=>{ closeModal(); if(CUR) sendMsg('gif','Regalo '+g); else alert(g); };
window.regenKey=async()=>{ const r=await api('POST','/api/regen-key'); if(r.key){ showModal(`<h3>🔑</h3><div class="key-box"><div class="key-row"><code>${r.key}</code></div></div><button class="btn-danger" onclick="closeModal()">✕</button>`); } };
async function showBots(){
  const r=await api('GET','/api/bots');
  showModal(`<h3>🤖 ${t('my_bots')}</h3><div id="bot-list">${(r.bots||[]).map(b=>`<div class="key-box" style="margin:8px 0"><b>${esc(b.name)}</b> @${esc(b.username)}<div class="key-row"><code style="font-size:12px">${b.token}</code></div><button class="btn-small" onclick="testBot('${b.token}')">Probar API</button></div>`).join('')}</div>
  <input id="b-name" placeholder="Nombre del bot"><input id="b-user" placeholder="@usuario_bot"><button class="btn-primary" id="b-create">Crear bot</button><button class="btn-danger" onclick="closeModal()">✕</button>`);
  $('b-create').onclick=async()=>{ const rr=await api('POST','/api/bots',{name:$('b-name').value,username:$('b-user').value}); if(rr.bot){ closeModal(); showBots(); } };
}
window.testBot=async(token)=>{ const text=prompt('Texto a enviar como bot (al chat abierto)'); if(!text||!CUR) return; const r=await fetch(`/api/bot/${token}/sendMessage`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:CUR.id,text})}).then(r=>r.json()); alert(r.ok?'Enviado ✓':'Error'); };
function enterApp2(){ $('drawer-name').textContent=ME.name; $('drawer-user').textContent='@'+ME.username; }
$('btn-new-chat').onclick=openNewChat;
$('btn-invite').onclick=()=>{ const link=location.origin; if(navigator.share) navigator.share({title:'BIN Y VUELTAS RD',text:'Únete a BIN Y VUELTAS RD',url:link}); else { navigator.clipboard.writeText(link); alert(link); } };

// Foto de perfil por upload
document.addEventListener('change', async e=>{
  if(e.target.id==='file-input'&&e.target.dataset.kind==='profile'){
    const f=e.target.files[0]; if(!f) return;
    const fd=new FormData(); fd.append('file',f);
    const r=await fetch('/api/upload',{method:'POST',headers:{'Authorization':'Bearer '+localStorage.getItem('bv_token')},body:fd}).then(r=>r.json());
    if(r.url){ $('p-photo').value=r.url; await api('POST','/api/profile',{photo:r.url}); const m=await api('GET','/api/me'); ME=m.user; }
    e.target.value=''; e.target.dataset.kind='';
  }
}, true);

// Regen key endpoint (simple)
// ---------- Banner de consentimiento de cookies ----------
(function(){
  try{
    if(!localStorage.getItem('bv_cookie')) $('cookie-banner').classList.remove('hidden');
    $('cookie-accept').onclick=()=>{ localStorage.setItem('bv_cookie','accepted'); $('cookie-banner').classList.add('hidden'); };
    $('cookie-decline').onclick=()=>{ localStorage.setItem('bv_cookie','declined'); $('cookie-banner').classList.add('hidden'); };
  }catch(e){}
})();

applyI18n();
(async()=>{ const tok=localStorage.getItem('bv_token'); if(tok){ const m=await api('GET','/api/me'); if(m.user){ ME=m.user; enterApp(); } } })();
